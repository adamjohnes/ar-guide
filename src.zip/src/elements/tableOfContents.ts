export type tableOfContents = {
  id: string,
  headings: string[]
}

export const tableOfContentSections: tableOfContents[] = [
  {
    id: 'page-setup-toc',
    headings: [
      'Overview',
      'Grid, Snap, Rulers',
      'Ribbon Tools',
      'Margins',
      'Orientation'
    ]
  },
  {
    id: '',
    headings: [
      'Examples'
    ]
  }
]