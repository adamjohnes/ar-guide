export type GuideSection = {
  id: string;
  path: string;
  title: string;
};

export type SubSection = {
  id: string;
  description: string;
  bullets: string[];
  details: string[];
  examples: string[];
}

export const guideSections: GuideSection[] = [
  {
    id: 'page-setup',
    path: '/guide/page-setup',
    title: 'Page Setup',
  },
  {
    id: 'parameters',
    path: '/guide/parameters',
    title: 'Parameters',
  },
  {
    id: 'connections',
    path: '/guide/connections',
    title: 'Connections',
  },
  {
    id: 'textboxes',
    path: '/guide/textboxes',
    title: 'Textboxes',
  },
  {
    id: 'tables',
    path: '/guide/tables',
    title: 'Tables',
  },
  {
    id: 'subreports',
    path: '/guide/subreports',
    title: 'Subreports',
  },
  {
    id: 'expressions',
    path: '/guide/expressions',
    title: 'Expressions',
  },
  {
    id: 'sections',
    path: '/guide/sections',
    title: 'Sections',
  }
]

export const subSections: SubSection[] = [
  {
    id: 'page-setup',
    description:
      'Use parameters to make reports dynamic by passing in values such as permit IDs, case IDs, or employee IDs.',
    bullets: [
      'Parameters are found under the Data tab.',
      'Create a parameter before referencing it in a query.',
      'Most common edits are Name, Prompt, and Data Type.'
    ],
    details: [
      'Parameters allow the same report to return different results depending on the value provided at runtime.',
      'A parameter should be created in the Parameters section before it is used inside a SELECT statement.',
      'Available Values can be used to create a drop-down list, but those fields should only be changed when needed.'
    ],
    examples: [
      'A permitID parameter could be used to return one permit record.',
      'A caseID parameter could be passed into a main report and then into a subreport.'
    ]
  }
]
