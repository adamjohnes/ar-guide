import { Link, useParams } from 'react-router';
import ChapterNav from '../components/ChapterNav';
import { guideSections } from '../elements/guideSections';
import { tableOfContentSections } from '../elements/tableOfContents';

const defaultTableOfContentHeadings = [
  'Overview',
  'Key Points',
  'Notes',
  'Examples'
];

function GuidePage() {
  const { sectionId } = useParams();
  const section = guideSections.find((item) => item.id === sectionId);
  const tocSection = tableOfContentSections.find((toc) => toc.id === `${sectionId ?? ''}-toc`);

  const tableOfContentHeadings =
    tocSection && tocSection.headings.length > 0
      ? tocSection.headings
      : defaultTableOfContentHeadings;

  const getHeadingId = (heading: string) => {
    const headingSlug = heading
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');

    return `${section?.id ?? 'guide'}-${headingSlug}`;
  };

  const handleTableOfContentsClick = (heading: string) => {
    document.getElementById(getHeadingId(heading))?.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });
  };

  if (!section) {
    return (
      <main className="mx-auto grid w-full max-w-7xl gap-6 px-6 py-8 lg:grid-cols-[16rem_1fr]">
        <ChapterNav />

        <div className="rounded-2xl border border-black bg-emerald-100 p-6">
          <h2 className="text-3xl font-bold text-black">
            Page Not Found
          </h2>

          <Link to="/" className="mt-6 inline-block font-semibold text-emerald-800 hover:text-black">
            Back to guide home
          </Link>
        </div>
      </main>
    );
  }

  const hasExamplesSection = tableOfContentHeadings.some(
    (heading) => heading.toLowerCase() === 'examples'
  );

  return (
    <main className="mx-auto grid w-full max-w-7xl gap-6 px-6 py-8 lg:grid-cols-[16rem_1fr]">
      <ChapterNav />
      <div className="grid gap-6">
        <nav className="rounded-2xl border border-black bg-emerald-50 p-5">
          <h2 className="text-sm font-bold uppercase tracking-[0.18em] text-black">
            Table of Contents
          </h2>
          <div className="mt-4 flex flex-col gap-2">
            {tableOfContentHeadings.map((heading) => (
              <button
                key={heading}
                type="button"
                onClick={() => handleTableOfContentsClick(heading)}
                className="rounded-2xl border border-gray-300 bg-white px-4 py-1 text-left text-sm font-semibold text-black hover:bg-emerald-100"
              >
                {heading}
              </button>
            ))}
          </div>
        </nav>
        <section className='rounded-2xl border border-black bg-emerald-50 p-5'>
          <div>
            <h1 className="scroll-mt-8 text-3xl font-bold text-black">{section.title}</h1>
          </div>
        </section>
        {hasExamplesSection && (
          <section className="rounded-2xl border border-black bg-emerald-50 p-6">
            <h2 id={getHeadingId('Examples')} className="scroll-mt-8 text-xl font-bold text-black">
              Examples
            </h2>

            <div className="mt-5 flex flex-col gap-3">
              {section.examples.map((example) => (
                <pre
                  key={example}
                  className="overflow-x-auto rounded-xl border border-black bg-emerald-800 p-4 text-sm text-white"
                >
                  <code>{example}</code>
                </pre>
              ))}
            </div>
          </section>
        )}
      </div>
    </main>
  );
}

export default GuidePage;